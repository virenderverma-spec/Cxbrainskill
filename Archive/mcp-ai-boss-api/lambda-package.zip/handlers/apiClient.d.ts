export interface APIRequest {
    method: string;
    path: string;
    params?: Record<string, any>;
    body?: any;
    headers?: Record<string, string>;
}
export interface APIResponse {
    status: number;
    data: any;
    headers: Record<string, string>;
}
export declare class APIClient {
    private client;
    private authHandler;
    private baseURL;
    constructor();
    /**
     * Make API request
     */
    request(req: APIRequest): Promise<APIResponse>;
    /**
     * Build path with path parameters
     */
    buildPath(template: string, params: Record<string, any>): string;
    /**
     * Get base URL
     */
    getBaseURL(): string;
}
//# sourceMappingURL=apiClient.d.ts.map