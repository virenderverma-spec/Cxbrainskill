/**
 * Authentication handler for AI-BOSS-API
 */
export class AuthHandler {
    apiKey;
    constructor() {
        const apiKey = process.env.AI_BOSS_API_KEY || process.env.AMDOCS_API_KEY;
        if (!apiKey) {
            throw new Error('AI_BOSS_API_KEY or AMDOCS_API_KEY environment variable is required');
        }
        this.apiKey = apiKey;
    }
    /**
     * Get API key
     */
    getApiKey() {
        return this.apiKey;
    }
    /**
     * Get headers with authentication
     */
    getAuthHeaders() {
        return {
            'X-API-Key': this.apiKey,
            'Content-Type': 'application/json',
        };
    }
    /**
     * Update API key (for runtime updates)
     */
    setApiKey(apiKey) {
        this.apiKey = apiKey;
    }
}
//# sourceMappingURL=auth.js.map