/**
 * Authentication handler for AI-BOSS-API
 */
export declare class AuthHandler {
    private apiKey;
    constructor();
    /**
     * Get API key
     */
    getApiKey(): string;
    /**
     * Get headers with authentication
     */
    getAuthHeaders(): Record<string, string>;
    /**
     * Update API key (for runtime updates)
     */
    setApiKey(apiKey: string): void;
}
//# sourceMappingURL=auth.d.ts.map