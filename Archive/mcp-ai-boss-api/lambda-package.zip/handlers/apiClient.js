import axios from 'axios';
import { AuthHandler } from './auth.js';
export class APIClient {
    client;
    authHandler;
    baseURL;
    constructor() {
        this.baseURL =
            process.env.AI_BOSS_API_BASE_URL || 'https://boss-api.rockstar-automations.com';
        this.authHandler = new AuthHandler();
        this.client = axios.create({
            baseURL: this.baseURL,
            timeout: 30000,
            headers: this.authHandler.getAuthHeaders(),
        });
        // Add request interceptor for logging
        this.client.interceptors.request.use((config) => {
            console.log(`[API Request] ${config.method?.toUpperCase()} ${config.url}`);
            return config;
        }, (error) => {
            console.error('[API Request Error]', error);
            return Promise.reject(error);
        });
        // Add response interceptor for error handling
        this.client.interceptors.response.use((response) => {
            return response;
        }, (error) => {
            console.error('[API Response Error]', {
                status: error.response?.status,
                message: error.message,
                data: error.response?.data,
            });
            return Promise.reject(error);
        });
    }
    /**
     * Make API request
     */
    async request(req) {
        const config = {
            method: req.method.toLowerCase(),
            url: req.path,
            params: req.params,
            data: req.body,
            headers: {
                ...this.authHandler.getAuthHeaders(),
                ...req.headers,
            },
        };
        try {
            const response = await this.client.request(config);
            return {
                status: response.status,
                data: response.data,
                headers: response.headers,
            };
        }
        catch (error) {
            if (error.response) {
                // API responded with error
                throw {
                    status: error.response.status,
                    message: error.response.data?.message || error.message,
                    data: error.response.data,
                };
            }
            else {
                // Network or other error
                throw {
                    status: 0,
                    message: error.message || 'Network error',
                    data: null,
                };
            }
        }
    }
    /**
     * Build path with path parameters
     */
    buildPath(template, params) {
        let path = template;
        // Replace path parameters
        for (const [key, value] of Object.entries(params)) {
            path = path.replace(`{${key}}`, String(value));
            path = path.replace(`:${key}`, String(value));
        }
        return path;
    }
    /**
     * Get base URL
     */
    getBaseURL() {
        return this.baseURL;
    }
}
//# sourceMappingURL=apiClient.js.map