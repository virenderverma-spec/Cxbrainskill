#!/usr/bin/env node
/**
 * MCP Client Test Script
 * Tests the MCP server by sending JSON-RPC requests
 */
export {};
//# sourceMappingURL=test-mcp-client.d.ts.map