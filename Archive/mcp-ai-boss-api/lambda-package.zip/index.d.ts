#!/usr/bin/env node
export {};
//# sourceMappingURL=index.d.ts.map