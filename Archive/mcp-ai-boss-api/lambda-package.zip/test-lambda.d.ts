#!/usr/bin/env node
/**
 * Test Lambda handler locally
 * Simulates API Gateway events to verify the handler works
 */
export {};
//# sourceMappingURL=test-lambda.d.ts.map