#!/usr/bin/env node
/**
 * Test script for MCP server
 * Tests tool generation and basic functionality
 */
export {};
//# sourceMappingURL=test-server.d.ts.map