import { Server } from '@modelcontextprotocol/sdk/server/index.js';
/**
 * Core MCP Server logic that can work with both stdio and HTTP transports
 */
export declare class MCPServerCore {
    private server;
    private toolGenerator;
    private toolExecutor;
    private tools;
    private initialized;
    private initializationPromise;
    constructor();
    /**
     * Initialize the server (load OpenAPI spec, generate tools)
     */
    initialize(): Promise<void>;
    private _doInitialize;
    /**
     * Load tools from OpenAPI spec
     */
    private loadTools;
    /**
     * Setup MCP request handlers
     */
    private setupHandlers;
    /**
     * Process a JSON-RPC request (for HTTP/Lambda)
     */
    processRequest(request: any): Promise<any>;
    /**
     * Get the server instance (for stdio transport)
     */
    getServer(): Server;
    /**
     * Get number of loaded tools
     */
    getToolCount(): number;
}
//# sourceMappingURL=mcpServerCore.d.ts.map