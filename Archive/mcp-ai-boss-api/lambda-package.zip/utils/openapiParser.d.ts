import { OpenAPIV3 } from 'openapi-types';
export interface ParsedEndpoint {
    path: string;
    method: string;
    operation: OpenAPIV3.OperationObject;
    operationId: string;
    tags: string[];
    parameters: OpenAPIV3.ParameterObject[];
    requestBody?: OpenAPIV3.RequestBodyObject;
    responses: OpenAPIV3.ResponsesObject;
    security?: OpenAPIV3.SecurityRequirementObject[];
}
export declare class OpenAPIParser {
    private spec;
    constructor(specPath?: string);
    /**
     * Parse all endpoints from OpenAPI spec
     */
    parseEndpoints(): ParsedEndpoint[];
    /**
     * Get all unique tags from the spec
     */
    getTags(): string[];
    /**
     * Get endpoints by tag
     */
    getEndpointsByTag(tag: string): ParsedEndpoint[];
    /**
     * Generate operation ID from path and method
     */
    private generateOperationId;
    /**
     * Get schema reference
     */
    getSchema(ref: string): OpenAPIV3.SchemaObject | null;
    /**
     * Resolve schema (handles $ref)
     */
    resolveSchema(schema: OpenAPIV3.SchemaObject | OpenAPIV3.ReferenceObject): OpenAPIV3.SchemaObject;
}
//# sourceMappingURL=openapiParser.d.ts.map