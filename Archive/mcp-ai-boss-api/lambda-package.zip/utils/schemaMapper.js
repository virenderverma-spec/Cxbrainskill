/**
 * Map OpenAPI schema to MCP tool input schema
 */
export class SchemaMapper {
    /**
     * Convert OpenAPI schema to MCP tool schema
     */
    mapToMCPSchema(schema, openAPISpec) {
        if (!schema) {
            return { type: 'object' };
        }
        // Handle $ref
        if ('$ref' in schema) {
            if (openAPISpec) {
                const refSchema = this.resolveRef(schema.$ref, openAPISpec);
                if (refSchema) {
                    return this.mapToMCPSchema(refSchema, openAPISpec);
                }
            }
            return { type: 'object' };
        }
        const openApiSchema = schema;
        // Handle different types
        switch (openApiSchema.type) {
            case 'string':
                return {
                    type: 'string',
                    description: openApiSchema.description,
                    enum: openApiSchema.enum,
                };
            case 'number':
            case 'integer':
                return {
                    type: 'number',
                    description: openApiSchema.description,
                };
            case 'boolean':
                return {
                    type: 'boolean',
                    description: openApiSchema.description,
                };
            case 'array':
                return {
                    type: 'array',
                    description: openApiSchema.description,
                    items: openApiSchema.items
                        ? this.mapToMCPSchema(openApiSchema.items, openAPISpec)
                        : { type: 'string' },
                };
            case 'object':
                const properties = {};
                const required = [];
                if (openApiSchema.properties) {
                    for (const [key, value] of Object.entries(openApiSchema.properties)) {
                        properties[key] = this.mapToMCPSchema(value, openAPISpec);
                    }
                }
                if (openApiSchema.required) {
                    required.push(...openApiSchema.required);
                }
                return {
                    type: 'object',
                    description: openApiSchema.description,
                    properties,
                    required: required.length > 0 ? required : undefined,
                };
            default:
                return {
                    type: 'object',
                    description: openApiSchema.description,
                };
        }
    }
    /**
     * Resolve $ref reference
     */
    resolveRef(ref, spec) {
        if (!ref.startsWith('#/components/schemas/')) {
            return null;
        }
        const schemaName = ref.replace('#/components/schemas/', '');
        return spec.components?.schemas?.[schemaName] || null;
    }
    /**
     * Map OpenAPI parameter to MCP tool parameter
     */
    mapParameter(parameter) {
        const schema = this.mapToMCPSchema(parameter.schema);
        return {
            name: parameter.name,
            schema,
            required: parameter.required || false,
            description: parameter.description,
            location: parameter.in,
        };
    }
    /**
     * Map request body to MCP tool schema
     */
    mapRequestBody(requestBody) {
        const content = requestBody.content;
        if (!content)
            return null;
        // Prefer application/json
        const jsonContent = content['application/json'];
        if (jsonContent?.schema) {
            return this.mapToMCPSchema(jsonContent.schema);
        }
        // Fallback to first content type
        const firstContent = Object.values(content)[0];
        if (firstContent?.schema) {
            return this.mapToMCPSchema(firstContent.schema);
        }
        return null;
    }
}
//# sourceMappingURL=schemaMapper.js.map