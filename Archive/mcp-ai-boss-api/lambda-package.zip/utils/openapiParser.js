import * as fs from 'fs';
import * as path from 'path';
export class OpenAPIParser {
    spec;
    constructor(specPath) {
        const defaultPath = path.join(process.cwd(), '..', 'AI-BOSS-API', 'generated', 'openapi.json');
        const specPathToUse = specPath || defaultPath;
        if (!fs.existsSync(specPathToUse)) {
            throw new Error(`OpenAPI spec not found at: ${specPathToUse}`);
        }
        const specContent = fs.readFileSync(specPathToUse, 'utf-8');
        this.spec = JSON.parse(specContent);
    }
    /**
     * Parse all endpoints from OpenAPI spec
     */
    parseEndpoints() {
        const endpoints = [];
        if (!this.spec.paths) {
            return endpoints;
        }
        for (const [path, pathItem] of Object.entries(this.spec.paths)) {
            if (!pathItem)
                continue;
            const methods = ['get', 'post', 'put', 'patch', 'delete'];
            for (const method of methods) {
                const operation = pathItem[method];
                if (!operation)
                    continue;
                const operationId = operation.operationId || this.generateOperationId(path, method);
                const tags = operation.tags || ['default'];
                const parameters = (operation.parameters || []);
                const requestBody = operation.requestBody;
                const responses = operation.responses || {};
                const security = operation.security || this.spec.security || [];
                endpoints.push({
                    path,
                    method: method.toUpperCase(),
                    operation,
                    operationId,
                    tags,
                    parameters,
                    requestBody,
                    responses,
                    security,
                });
            }
        }
        return endpoints;
    }
    /**
     * Get all unique tags from the spec
     */
    getTags() {
        const tags = new Set();
        for (const endpoint of this.parseEndpoints()) {
            endpoint.tags.forEach(tag => tags.add(tag));
        }
        return Array.from(tags).sort();
    }
    /**
     * Get endpoints by tag
     */
    getEndpointsByTag(tag) {
        return this.parseEndpoints().filter(ep => ep.tags.includes(tag));
    }
    /**
     * Generate operation ID from path and method
     */
    generateOperationId(path, method) {
        const pathParts = path
            .replace(/[{}]/g, '')
            .split('/')
            .filter(p => p)
            .map(p => p.replace(/[^a-zA-Z0-9]/g, '_'));
        const methodPrefix = method.toLowerCase();
        const pathSuffix = pathParts.join('_');
        return `${methodPrefix}_${pathSuffix}`;
    }
    /**
     * Get schema reference
     */
    getSchema(ref) {
        if (!ref.startsWith('#/components/schemas/')) {
            return null;
        }
        const schemaName = ref.replace('#/components/schemas/', '');
        return this.spec.components?.schemas?.[schemaName] || null;
    }
    /**
     * Resolve schema (handles $ref)
     */
    resolveSchema(schema) {
        if ('$ref' in schema) {
            const resolved = this.getSchema(schema.$ref);
            return resolved || { type: 'object' };
        }
        return schema;
    }
}
//# sourceMappingURL=openapiParser.js.map