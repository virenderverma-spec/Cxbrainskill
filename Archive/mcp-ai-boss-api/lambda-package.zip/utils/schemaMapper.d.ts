import { OpenAPIV3 } from 'openapi-types';
export interface MCPToolSchema {
    type: string;
    properties?: Record<string, any>;
    required?: string[];
    description?: string;
    items?: any;
    enum?: any[];
}
/**
 * Map OpenAPI schema to MCP tool input schema
 */
export declare class SchemaMapper {
    /**
     * Convert OpenAPI schema to MCP tool schema
     */
    mapToMCPSchema(schema: OpenAPIV3.SchemaObject | OpenAPIV3.ReferenceObject | undefined, openAPISpec?: OpenAPIV3.Document): MCPToolSchema;
    /**
     * Resolve $ref reference
     */
    private resolveRef;
    /**
     * Map OpenAPI parameter to MCP tool parameter
     */
    mapParameter(parameter: OpenAPIV3.ParameterObject): {
        name: string;
        schema: MCPToolSchema;
        required: boolean;
        description?: string;
        location: string;
    };
    /**
     * Map request body to MCP tool schema
     */
    mapRequestBody(requestBody: OpenAPIV3.RequestBodyObject): MCPToolSchema | null;
}
//# sourceMappingURL=schemaMapper.d.ts.map