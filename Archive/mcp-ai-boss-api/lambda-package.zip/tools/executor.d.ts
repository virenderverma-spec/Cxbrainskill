import { GeneratedTool } from './generator.js';
export interface ToolExecutionResult {
    success: boolean;
    data?: any;
    error?: {
        message: string;
        status?: number;
        details?: any;
    };
}
export declare class ToolExecutor {
    private apiClient;
    constructor();
    /**
     * Execute a tool with given arguments
     */
    execute(tool: GeneratedTool, args: Record<string, any>): Promise<ToolExecutionResult>;
}
//# sourceMappingURL=executor.d.ts.map