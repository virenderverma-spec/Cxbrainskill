import { ParsedEndpoint } from '../utils/openapiParser.js';
import { Tool } from '@modelcontextprotocol/sdk/types.js';
export interface GeneratedTool extends Tool {
    endpoint: ParsedEndpoint;
    handler: string;
}
export declare class ToolGenerator {
    private parser;
    private mapper;
    constructor(openAPISpecPath?: string);
    /**
     * Generate all MCP tools from OpenAPI spec
     */
    generateAllTools(): GeneratedTool[];
    /**
     * Generate MCP tool from OpenAPI endpoint
     */
    generateTool(endpoint: ParsedEndpoint): GeneratedTool;
    /**
     * Sanitize operation ID for MCP tool name
     */
    private sanitizeOperationId;
    /**
     * Build tool description from OpenAPI operation
     */
    private buildDescription;
    /**
     * Build input schema for MCP tool
     */
    private buildInputSchema;
    /**
     * Get tools by tag
     */
    getToolsByTag(tag: string): GeneratedTool[];
    /**
     * Get all tags
     */
    getTags(): string[];
}
//# sourceMappingURL=generator.d.ts.map